#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

#include "meshes (1).h"

// image loading functions
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

// GLM math header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpengl/camera.h> // camera class

using namespace std; // standard namespace

// shader program
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// unnamed namespace
namespace
{
    // window title
    const char* const WINDOW_TITLE = "Tea Time";

    // variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    Meshes meshes;

    // stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;
        GLuint vbos[2];
        GLuint nIndices;
		GLuint nVertices;
    };

    // main GLFW window
    GLFWwindow* gWindow = nullptr;
    // triangle mesh data
    GLMesh gMesh;
    // shader program
    GLuint gProgramId;
    GLuint gLampProgramId;

    // texture set up
    GLuint gTextureMugId;
    GLuint gTextureGlossId;
    GLuint gTextureTableId;
    GLuint gTextureSpoonId;
    GLuint gTextureCoffeeId;
    GLuint gTexturePlateId;
    GLuint gTextureCakeSideId;
    GLuint gTextureCakeTopId;
    GLuint gTextureCherryId;
    glm::vec2 gUVScale(1.0f, 1.0f);
    GLint gTexWrapMode = GL_REPEAT;
    bool gTexture2on = true;

    // camera set up
    glm::vec3 cameraPos = glm::vec3(0.0f, 3.0f, 7.0f);
    glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
    glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

    GLuint gCurrentCameraIndex = 1;
    GLfloat gCameraZoom = 45.0f;
    GLuint gCameraOrtho = 0;

    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    float yaw = -90.0f;
    float pitch = 0.0f; 
    float fov = 45.0f;

    // timing 
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // light setup
    glm::vec3 gLightColor(1.0f, 0.9f, 0.85f);
    glm::vec3 gLightPosition(5.0f, 10.0f, 0.0f);
    glm::vec3 gLightScale(2.0);
}

// user defined Functions to:
// initialize the program, set the window size,
// redraw graphics on the window when resized,
// and render graphics on the screen
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);

void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);

void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double uoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);


// vertex shader source code
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // vertex data from vertex attrib pointer 0
    layout(location = 1) in vec3 normal; // vertex attrib pointer 1 for normals
    layout(location = 2) in vec2 textureCoordinate; // texture data from vertex attrib pointer 2

    out vec3 vertexNormal;
    out vec3 vertexFragmentPos;
    out vec2 vertexTextureCoordinate;

    // global variables for transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        // transforms vertices to clip coordinates
        gl_Position = projection * view * model * vec4(position, 1.0f);

        // gets fragment/pixel position in world space
        vertexFragmentPos = vec3(model * vec4(position, 1.0));

        // gets normal vectors in world space
        vertexNormal = mat3(transpose(inverse(model))) * normal;
        vertexTextureCoordinate = textureCoordinate;
    }
);


// fragment shader source code
const GLchar* fragmentShaderSource = GLSL(440,

    // variables for incoming normals, fragment position, and texture
    in vec3 vertexNormal;
    in vec3 vertexFragmentPos;
    in vec2 vertexTextureCoordinate;

    out vec4 fragmentColor;
    
    uniform vec3 lightColor;
    uniform vec3 lightPos;
    uniform vec3 viewPosition;
    uniform sampler2D uTexture;
    uniform vec2 uvScale;

    void main()
    {
        // calculate ambient lighting
        float ambientStrength = 0.3f;
        vec3 ambient = ambientStrength * lightColor;

        // calculate diffuse lighting
        vec3 norm = normalize(vertexNormal);
        vec3 lightDirection = normalize(lightPos - vertexFragmentPos);
        float impact = max(dot(norm, lightDirection), 0.0f);
        vec3 diffuse = impact * lightColor;

        // calculate specular lighting
        float specularIntensity = 0.1f;
        float highlightSize = 16.0f;
        vec3 viewDir = normalize(viewPosition - vertexFragmentPos);
        vec3 reflectDir = reflect(-lightDirection, norm);

        float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
        vec3 specular = specularIntensity * specularComponent * lightColor;

        // texture holds the color for all three components
        vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

        // calculate phong result
        vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;
        fragmentColor = vec4(phong, 1.0);
    }
);


// lamp shader source code
const GLchar* lampVertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;

    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main() {
        gl_Position = projection * view * model * vec4(position, 1.0f);
    }
);

// lamp fragment shader source code
const GLchar* lampFragmentShaderSource = GLSL(440,
    out vec4 fragmentColor;

    void main() {
        fragmentColor = vec4(1.0f);
    }
);


// flip image right side up
void flipImageVertically(unsigned char* image, int width, int height, int channels) {

    for (int j = 0; j < height / 2; ++j) {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i) {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // create mesh
    meshes.CreateMeshes();

    // create the shader program
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;
    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // load textures
    const char* texFilename = "../../Project 1/teacup3.jpg";
    if (!UCreateTexture(texFilename, gTextureMugId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/gloss.jpg";
    if (!UCreateTexture(texFilename, gTextureGlossId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/table.jpg";
    if (!UCreateTexture(texFilename, gTextureTableId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/spoon2.jpg";
    if (!UCreateTexture(texFilename, gTextureSpoonId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/coffee.jpg";
    if (!UCreateTexture(texFilename, gTextureCoffeeId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/plate3.jpg";
    if (!UCreateTexture(texFilename, gTexturePlateId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/cakeSide2.jpg";
    if (!UCreateTexture(texFilename, gTextureCakeSideId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/cakeTop1.jpg";
    if (!UCreateTexture(texFilename, gTextureCakeTopId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../Project 1/cherry3.jpg";
    if (!UCreateTexture(texFilename, gTextureCherryId)) {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    glUseProgram(gProgramId);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    // sets the background color to black
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    while (!glfwWindowShouldClose(gWindow))
    {
        // per frame timing 
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        UProcessInput(gWindow);

        // render this frame
        URender();
		//URender2();

        glfwPollEvents();
    }

    // release mesh data
    meshes.DestroyMeshes();

    // release texture data
    UDestroyTexture(gTextureMugId);
    UDestroyTexture(gTextureGlossId);
    UDestroyTexture(gTextureTableId);
    UDestroyTexture(gTextureSpoonId);
    UDestroyTexture(gTextureCoffeeId);
    UDestroyTexture(gTextureCakeSideId);
    UDestroyTexture(gTextureCakeTopId);
    UDestroyTexture(gTextureCherryId);

    // release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLampProgramId);

    // terminate program
    exit(EXIT_SUCCESS);
}


// initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW initialize and configure
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW window creation
    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // capture the mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW initialize
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input
void UProcessInput(GLFWwindow* window)
{
    float cameraSpeed = 2.5f * gDeltaTime;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        cameraPos -= cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        cameraPos += cameraSpeed * cameraUp;

    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
        gCameraOrtho = 1;
        cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
        cameraPos = glm::vec3(0.0f, 0.0f, 10.0f);
    }
}


// glfw whenever the window size changes this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// when mouse moves, this callback is called
void UMousePositionCallback(GLFWwindow* window, double xposIn, double yposIn)
{
    float xpos = static_cast<float>(xposIn);
    float ypos = static_cast<float>(yposIn);

    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top
    gLastX = xpos;
    gLastY = ypos;

    float sensitivity = 0.1f; // change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    yaw += xoffset;
    pitch += yoffset;

    // make sure that when pitch is out of bounds, screen doesn't get flipped
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;

    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}

void ProcessMouseScroll(float yoffset) {
    float MovementSpeed = 2.5f * gDeltaTime;
    MovementSpeed += (float)yoffset;
    if (MovementSpeed < 0.1f) {
        MovementSpeed = 0.1f;
    }
    std::cout << "movement_speed: " << MovementSpeed;
}

// when scroll wheel moves, this callback is called
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset) {    
    ProcessMouseScroll(yoffset);
}


// handles mouse button events
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods) {

    switch (button) {

    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// functioned called to render a frame
void URender()
{
	// enable z-depth
	glEnable(GL_DEPTH_TEST);

	// clear the frame and z buffers
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    
    glm::mat4 projection = glm::perspective(glm::radians(gCameraZoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 1000.0f);
	
	// set the shader to be used
	glUseProgram(gProgramId);
	
	// move the camera back
	glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

	GLint modelLoc = glGetUniformLocation(gProgramId, "model");
	GLint viewLoc = glGetUniformLocation(gProgramId, "view");
	GLint projLoc = glGetUniformLocation(gProgramId, "projection");
    //GLint uCustomColorLoc = glGetUniformLocation(gProgramId, "uCustomColor");
	
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

    // light aspect 
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);

    // Mug Body
	// activate VBOs contained within mesh's VAO
	glBindVertexArray(meshes.gTaperedCylinderMesh.vao);

	// scales the object 
	glm::mat4 scale = glm::scale(glm::vec3(1.0f, 1.3f, 1.0f));
	// rotates shape
	glm::mat4 rotation = glm::rotate(3.14f, glm::vec3(0.0f, 0.0f, 5.0f));
	// place object at the origin
	glm::mat4 translation = glm::translate(glm::vec3(0.0f, 1.3f, 0.0f));
	// model matrix, transformations are applied right-to-left order
	glm::mat4 model = translation * rotation * scale;

	// retrieves and passes transform matrices to the Shader program
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureMugId); 

	// draws the cylinder
    //glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		//top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides


    // Tea Inside Mug
    // scales the object 
    scale = glm::scale(glm::vec3(0.9f, 0.95f, 0.9f));
    // rotates shape
    rotation = glm::rotate(3.14f, glm::vec3(0.0f, 0.0f, 5.0f));
    // place object at the origin
    translation = glm::translate(glm::vec3(0.0f, 1.1f, 0.0f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    // retrieves and passes transform matrices to the Shader program
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCoffeeId);

    // draws the cylinder
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		// bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);	    // top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);   // sides

    // deactivate the vertex array object
    glBindVertexArray(0);

    
    // Mug Bottom
    // activate VBOs within mesh's VAO
    glBindVertexArray(meshes.gCylinderMesh.vao);

	// scales the object
	scale = glm::scale(glm::vec3(0.45f, 0.15f, 0.45f));
	// rotates shape
	rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
	// moves the object
	translation = glm::translate(glm::vec3(0.0f, -0.10f, 0.0f));
	// model matrix, transformations are applied right-to-left order
	model = translation * rotation * scale;

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureGlossId);

	// draws cylinder
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		// bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);		// top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);   // sides


    // Cherry Stem
    // scales the object 
    scale = glm::scale(glm::vec3(0.01f, 1.0f, 0.01f));
    // rotates shape
    rotation = glm::rotate(1.2f, glm::vec3(0.0f, 0.0f, 3.0f));
    // place object at the origin
    translation = glm::translate(glm::vec3(0.0f, 0.9f, 2.5f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    // retrieves and passes transform matrices to the Shader program
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCoffeeId);

    // draws the cylinder
    glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		// bottom
    glDrawArrays(GL_TRIANGLE_FAN, 36, 72);	// top
    glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);   // sides

    // deactivate the vertex array object
    glBindVertexArray(0);


    // Mug Handle
	// activate VBOs contained within mesh's VAO
	glBindVertexArray(meshes.gTorusMesh.vao);

	// scales the object
	scale = glm::scale(glm::vec3(0.3f, 0.5f, 1.0f));
	// rotates shape
	rotation = glm::rotate(1.3f, glm::vec3(0.0f, 0.0f, -5.0f));
	// moves object
	translation = glm::translate(glm::vec3(0.6f, 0.65f, 0.0f));
	// model matrix, transformations are applied right-to-left order
	model = translation * rotation * scale;

	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureGlossId);

	// draws the torus
    glDrawArrays(GL_TRIANGLES, 0, meshes.gTorusMesh.nVertices);

	// deactivate the vertex array object
	glBindVertexArray(0);


    // Plate
    // activate VBOs contained within mesh's VAO
    glBindVertexArray(meshes.gSphereMesh.vao);

    // scales the object
    scale = glm::scale(glm::vec3(1.5f, 0.2f, 1.5f));
    // rotates shape
    rotation = glm::rotate(3.12f, glm::vec3(5.0f, 0.0f, 0.0f));
    // moves object
    translation = glm::translate(glm::vec3(0.0f, 0.1f, 2.5f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureMugId);

    // draws the sphere
    glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices/2, GL_UNSIGNED_INT, (void*)0);

 
    // Cherry
    // scales the object
    scale = glm::scale(glm::vec3(0.17f, 0.2f, 0.17f));
    // rotates shape
    rotation = glm::rotate(1.2f, glm::vec3(0.0f, 0.0f, 2.0f));
    // moves object
    translation = glm::translate(glm::vec3(0.0f, 0.92f, 2.5f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCherryId);

    // draws the sphere
    glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


    // Cherry Stem Tip
    // scales the object
    scale = glm::scale(glm::vec3(0.03f, 0.04f, 0.03f));
    // rotates shape
    rotation = glm::rotate(1.2f, glm::vec3(0.0f, 0.0f, 2.0f));
    // moves object
    translation = glm::translate(glm::vec3(-0.95f, 1.27f, 2.5f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCoffeeId);

    // draws the sphere
    glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


    // Spoon Head
    // scales the object
    scale = glm::scale(glm::vec3(0.3f, 0.15f, 0.5f));
    // rotates shape
    rotation = glm::rotate(3.35f, glm::vec3(5.0f, 0.0f, 0.0f));
    // moves object
    translation = glm::translate(glm::vec3(1.0f, 0.23f, 1.8f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureSpoonId);

    // draws the sphere
    glDrawElements(GL_TRIANGLES, meshes.gSphereMesh.nIndices / 2, GL_UNSIGNED_INT, (void*)0);

    // deactivate the vertex array object
    glBindVertexArray(0);


    // Spoon Handle
    // activate VBOs contained within mesh's VAO
    glBindVertexArray(meshes.gBoxMesh.vao);

    // scales the object 
    scale = glm::scale(glm::vec3(0.1f, 1.5f, 0.02f));
    // rotates shape
    rotation = glm::rotate(1.55f, glm::vec3(5.0f, 0.0f, 0.0f));
    // place object at the origin
    translation = glm::translate(glm::vec3(1.0f, 0.1f, 3.0f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    // retrieves and passes transform matrices to the Shader program
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureSpoonId);

    // draws the box
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


    // Cake Top
    // scales the object 
    scale = glm::scale(glm::vec3(1.3f, 0.1f, 1.3f));
    // rotates shape
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    // place object at the origin
    translation = glm::translate(glm::vec3(0.0f, 0.74f, 2.5f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    // retrieves and passes transform matrices to the Shader program
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCakeTopId);

    // draws the box
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


    // Cake Body
    // scales the object 
    scale = glm::scale(glm::vec3(1.3f, 0.75f, 1.3f));
    // rotates shape
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    // place object at the origin
    translation = glm::translate(glm::vec3(0.0f, 0.32f, 2.5f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    // retrieves and passes transform matrices to the Shader program
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureCakeSideId);

    // draws the box
    glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // deactivate the vertex array object
    glBindVertexArray(0);


    // Table Top 
    glBindVertexArray(meshes.gPlaneMesh.vao);

    // scales the object
    scale = glm::scale(glm::vec3(10.0f, 2.0f, 10.0f));
    // rotates shape
    rotation = glm::rotate(0.0f, glm::vec3(1.0f, 1.0f, 1.0f));
    // moves object
    translation = glm::translate(glm::vec3(0.0f, -0.12f, 0.0f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTableId);

    // draws the plane
    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // deactivate the vertex array object
    //glBindVertexArray(0);


    // White Wall -X
    // scales the object
    scale = glm::scale(glm::vec3(5.0f, 2.0f, 10.0f));
    // rotates shape
    rotation = glm::rotate(1.57f, glm::vec3(0.0f, 0.0f, 5.0f));
    // moves object
    translation = glm::translate(glm::vec3(-10.0f, 4.8f, 0.0f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTableId);

    // draws the plane
    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


    // White Wall X
    // scales the object
    scale = glm::scale(glm::vec3(5.0f, 2.0f, 10.0f));
    // rotates shape
    rotation = glm::rotate(1.57f, glm::vec3(0.0f, 0.0f, 5.0f));
    // moves object
    translation = glm::translate(glm::vec3(10.0f, 4.8f, 0.0f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTableId);

    // draws the plane
    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


    // White Wall -Z
    // scales the object
    scale = glm::scale(glm::vec3(10.0f, 2.0f, 5.0f));
    // rotates shape
    rotation = glm::rotate(1.57f, glm::vec3(5.0f, 0.0f, 0.0f));
    // moves object
    translation = glm::translate(glm::vec3(0.0f, 4.8f, -10.0f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTableId);

    // draws the plane
    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);


    // White Wall Z
    // scales the object
    scale = glm::scale(glm::vec3(10.0f, 2.0f, 5.0f));
    // rotates shape
    rotation = glm::rotate(1.57f, glm::vec3(5.0f, 0.0f, 0.0f));
    // moves object
    translation = glm::translate(glm::vec3(0.0f, 4.8f, 10.0f));
    // model matrix, transformations are applied right-to-left order
    model = translation * rotation * scale;

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    // bind texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTableId);

    // draws the plane
    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // deactivate the vertex array object
    glBindVertexArray(0);


    // LAMP 1
    glUseProgram(gLampProgramId);
    glBindVertexArray(meshes.gPlaneMesh.vao);

    //Transform the small sphere used as a visual que for the light source
    model = glm::translate(gLightPosition) * glm::scale(gLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);


    // LAMP 2
    glUseProgram(gLampProgramId);
    glBindVertexArray(meshes.gPlaneMesh.vao);

    //Transform the small sphere used as a visual que for the light source
    model = glm::translate(glm::vec3(-5.0f, 10.0f, 0.0f)) * glm::scale(gLightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = glGetUniformLocation(gLampProgramId, "model");
    viewLoc = glGetUniformLocation(gLampProgramId, "view");
    projLoc = glGetUniformLocation(gLampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

    // Deactivate the Vertex Array Object and shader program
    glBindVertexArray(0);
    glUseProgram(0);

	// glfw swap buffers and poll IO events
	glfwSwapBuffers(gWindow);
}


// generate and load textures
bool UCreateTexture(const char* filename, GLuint& textureId) {

    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image){
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set texture wrapping 
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        // set texture filtering
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        return true;
    }

    // error loading image
    return false;
}

void UDestroyTexture(GLuint textureId) {
    glGenTextures(1, &textureId);
}


// implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // create a shader program object.
    programId = glCreateProgram();

    // create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // compile the vertex shader, and print compilation errors
    glCompileShader(vertexShaderId);
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // compile the fragment shader, and print compilation errors
    glCompileShader(fragmentShaderId);
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // attached compiled shaders to shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    // links the shader program and checks for linking errors
    glLinkProgram(programId);
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // uses the shader program
    glUseProgram(programId);

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}